document.addEventListener('DOMContentLoaded', () => {

  const cfsListPanel = document.getElementById('cfsListPanel');
  const detailDrawer = document.getElementById('detailDrawer');
  const cfsList = document.getElementById('cfsList');
  const backBtn = document.getElementById('backBtn');

  // Open detail drawer when a card is clicked
  cfsList.addEventListener('click', (e) => {
    const card = e.target.closest('.cfs-card');
    if (!card) return;
    document.getElementById('detailId').textContent = card.dataset.id;
    cfsListPanel.style.display = 'none';
    detailDrawer.classList.add('show');
  });

  // Back button returns to list
  backBtn.addEventListener('click', () => {
    detailDrawer.classList.remove('show');
    cfsListPanel.style.display = 'flex';
  });

  // Top tabs: My CFS / Active / Inactive
  document.querySelectorAll('#cfsTabs .tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('#cfsTabs .tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  // Detail tabs: Overview / Involved entities / Narratives / Media / More
  document.querySelectorAll('#detailTabs .dtab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('#detailTabs .dtab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const paneKey = tab.dataset.dtab;
      document.querySelectorAll('.dpane').forEach(p => p.classList.remove('active'));
      document.querySelector(`.dpane[data-pane="${paneKey}"]`).classList.add('active');
    });
  });

  // Sort dropdown toggle
  const sortBtn = document.getElementById('sortBtn');
  const sortDropdown = document.getElementById('sortDropdown');
  sortBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    sortDropdown.classList.toggle('show');
  });
  sortDropdown.querySelectorAll('.sort-item').forEach(item => {
    item.addEventListener('click', () => {
      sortDropdown.querySelectorAll('.sort-item').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      sortDropdown.classList.remove('show');
    });
  });

  // Kebab dropdown toggle (detail header)
  const kebabBtn = document.getElementById('kebabBtn');
  const kebabDropdown = document.getElementById('kebabDropdown');
  kebabBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    kebabDropdown.classList.toggle('show');
  });

  // Status dropdown (En route / On scene / etc.)
  const statusBtn = document.getElementById('statusBtn');
  const statusDropdown = document.getElementById('statusDropdown');
  const statusLabel = document.getElementById('statusLabel');
  statusBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    statusDropdown.classList.toggle('show');
    statusBtn.classList.toggle('open');
  });
  statusDropdown.querySelectorAll('.status-item').forEach(item => {
    item.addEventListener('click', () => {
      const val = item.dataset.status;
      if (val !== 'Cancel assignment' && val !== 'Complete assignment') {
        statusLabel.textContent = val;
      }
      statusDropdown.querySelectorAll('.check-icon').forEach(c => c.remove());
      if (!item.querySelector('.check-icon')) {
        const check = document.createElement('svg');
        check.setAttribute('viewBox', '0 0 24 24');
        check.setAttribute('fill', 'none');
        check.classList.add('check-icon');
        check.innerHTML = '<path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>';
        item.appendChild(check);
      }
      statusDropdown.classList.remove('show');
      statusBtn.classList.remove('open');
    });
  });

  // Close any open dropdown when clicking outside
  document.addEventListener('click', () => {
    sortDropdown.classList.remove('show');
    kebabDropdown.classList.remove('show');
    statusDropdown.classList.remove('show');
    statusBtn.classList.remove('open');
  });

  // Narrative selection in narratives tab
  document.querySelectorAll('.narrative-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.narrative-item').forEach(i => i.classList.remove('selected'));
      item.classList.add('selected');
    });
  });

  // Subtabs in Involved Entities (Persons/Organizations/Vehicles/Properties)
  document.querySelectorAll('.subtab').forEach(tab => {
    tab.addEventListener('click', () => {
      tab.parentElement.querySelectorAll('.subtab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  // Create New CFS modal
  const createBtn = document.getElementById('createCfsBtn');
  const modalOverlay = document.getElementById('createModalOverlay');
  createBtn.addEventListener('click', () => {
    modalOverlay.classList.add('show');
  });
  modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) modalOverlay.classList.remove('show');
  });

  // Modal tabs
  document.querySelectorAll('.mtab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.mtab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  // Submit to dispatcher -> close modal, return to list
  document.getElementById('submitDispatchBtn').addEventListener('click', () => {
    modalOverlay.classList.remove('show');
  });

  // Chip remove buttons
  document.querySelectorAll('.chip-x').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      btn.closest('.chip').remove();
    });
  });

  // Address input clear
  document.querySelector('.addr-clear')?.addEventListener('click', () => {
    document.querySelector('.address-input input').value = '';
  });

});
