import{u as xt,c as Z,a as be,b as J,s as ut,m as Ve,i as u,k as Ct,e as b,f as l,d as w,l as L,M as Le,j as se,F as wt,S as kt,n as ft,t as _,o as St,p as Ge,q as _t,r as gt,v as Ue}from"./index-Dx1uiuj4.js";import{e as me,d as U,t as nt,i as Ft}from"./index-xJOr-_jp.js";let zt={data:""},Et=t=>{if(typeof window=="object"){let e=(t?t.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return e.nonce=window.__nonce__,e.parentNode||(t||document.head).appendChild(e),e.firstChild}return t||zt},Bt=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,Dt=/\/\*[^]*?\*\/|  +/g,it=/\n+/g,oe=(t,e)=>{let i="",r="",f="";for(let o in t){let g=t[o];o[0]=="@"?o[1]=="i"?i=o+" "+g+";":r+=o[1]=="f"?oe(g,o):o+"{"+oe(g,o[1]=="k"?"":e)+"}":typeof g=="object"?r+=oe(g,e?e.replace(/([^,])+/g,v=>o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,c=>/&/.test(c)?c.replace(/&/g,v):v?v+" "+c:c)):o):g!=null&&(o=o[1]=="-"?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),f+=oe.p?oe.p(o,g):o+":"+g+";")}return i+(e&&f?e+"{"+f+"}":f)+r},ne={},vt=t=>{if(typeof t=="object"){let e="";for(let i in t)e+=i+vt(t[i]);return e}return t},It=(t,e,i,r,f)=>{let o=vt(t),g=ne[o]||(ne[o]=(c=>{let a=0,n=11;for(;a<c.length;)n=101*n+c.charCodeAt(a++)>>>0;return"go"+n})(o));if(!ne[g]){let c=o!==t?t:(a=>{let n,C,p=[{}];for(;n=Bt.exec(a.replace(Dt,""));)n[4]?p.shift():n[3]?(C=n[3].replace(it," ").trim(),p.unshift(p[0][C]=p[0][C]||{})):p[0][n[1]]=n[2].replace(it," ").trim();return p[0]})(t);ne[g]=oe(f?{["@keyframes "+g]:c}:c,i?"":"."+g)}let v=i&&ne.g;return i&&(ne.g=ne[g]),((c,a,n,C)=>{C?a.data=a.data.replace(C,c):a.data.indexOf(c)===-1&&(a.data=n?c+a.data:a.data+c)})(ne[g],e,r,v),g},Tt=(t,e,i)=>t.reduce((r,f,o)=>{let g=e[o];if(g&&g.call){let v=g(i),c=v&&v.props&&v.props.className||/^go/.test(v)&&v;g=c?"."+c:v&&typeof v=="object"?v.props?"":oe(v,""):v===!1?"":v}return r+f+(g??"")},"");function de(t){let e=this||{},i=t.call?t(e.p):t;return It(i.unshift?i.raw?Tt(i,[].slice.call(arguments,1),e.p):i.reduce((r,f)=>Object.assign(r,f&&f.call?f(e.p):f),{}):i,Et(e.target),e.g,e.o,e.k)}de.bind({g:1});de.bind({k:1});var E={colors:{inherit:"inherit",current:"currentColor",transparent:"transparent",black:"#000000",white:"#ffffff",neutral:{50:"#f9fafb",100:"#f2f4f7",200:"#eaecf0",300:"#d0d5dd",400:"#98a2b3",500:"#667085",600:"#475467",700:"#344054",800:"#1d2939",900:"#101828"},darkGray:{50:"#525c7a",100:"#49536e",200:"#414962",300:"#394056",400:"#313749",500:"#292e3d",600:"#212530",700:"#191c24",800:"#111318",900:"#0b0d10"},gray:{50:"#f9fafb",100:"#f2f4f7",200:"#eaecf0",300:"#d0d5dd",400:"#98a2b3",500:"#667085",600:"#475467",700:"#344054",800:"#1d2939",900:"#101828"},blue:{25:"#F5FAFF",50:"#EFF8FF",100:"#D1E9FF",200:"#B2DDFF",300:"#84CAFF",400:"#53B1FD",500:"#2E90FA",600:"#1570EF",700:"#175CD3",800:"#1849A9",900:"#194185"},green:{25:"#F6FEF9",50:"#ECFDF3",100:"#D1FADF",200:"#A6F4C5",300:"#6CE9A6",400:"#32D583",500:"#12B76A",600:"#039855",700:"#027A48",800:"#05603A",900:"#054F31"},red:{50:"#fef2f2",100:"#fee2e2",200:"#fecaca",300:"#fca5a5",400:"#f87171",500:"#ef4444",600:"#dc2626",700:"#b91c1c",800:"#991b1b",900:"#7f1d1d",950:"#450a0a"},yellow:{25:"#FFFCF5",50:"#FFFAEB",100:"#FEF0C7",200:"#FEDF89",300:"#FEC84B",400:"#FDB022",500:"#F79009",600:"#DC6803",700:"#B54708",800:"#93370D",900:"#7A2E0E"},purple:{25:"#FAFAFF",50:"#F4F3FF",100:"#EBE9FE",200:"#D9D6FE",300:"#BDB4FE",400:"#9B8AFB",500:"#7A5AF8",600:"#6938EF",700:"#5925DC",800:"#4A1FB8",900:"#3E1C96"},teal:{25:"#F6FEFC",50:"#F0FDF9",100:"#CCFBEF",200:"#99F6E0",300:"#5FE9D0",400:"#2ED3B7",500:"#15B79E",600:"#0E9384",700:"#107569",800:"#125D56",900:"#134E48"},pink:{25:"#fdf2f8",50:"#fce7f3",100:"#fbcfe8",200:"#f9a8d4",300:"#f472b6",400:"#ec4899",500:"#db2777",600:"#be185d",700:"#9d174d",800:"#831843",900:"#500724"},cyan:{25:"#ecfeff",50:"#cffafe",100:"#a5f3fc",200:"#67e8f9",300:"#22d3ee",400:"#06b6d4",500:"#0891b2",600:"#0e7490",700:"#155e75",800:"#164e63",900:"#083344"}},alpha:{90:"e5",70:"b3",20:"33"},font:{size:{"2xs":"calc(var(--tsrd-font-size) * 0.625)",xs:"calc(var(--tsrd-font-size) * 0.75)",sm:"calc(var(--tsrd-font-size) * 0.875)",md:"var(--tsrd-font-size)"},lineHeight:{xs:"calc(var(--tsrd-font-size) * 1)",sm:"calc(var(--tsrd-font-size) * 1.25)"},weight:{normal:"400",medium:"500",semibold:"600",bold:"700"},fontFamily:{sans:"ui-sans-serif, Inter, system-ui, sans-serif, sans-serif",mono:"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace"}},border:{radius:{xs:"calc(var(--tsrd-font-size) * 0.125)",sm:"calc(var(--tsrd-font-size) * 0.25)",md:"calc(var(--tsrd-font-size) * 0.375)",full:"9999px"}},size:{0:"0px",.5:"calc(var(--tsrd-font-size) * 0.125)",1:"calc(var(--tsrd-font-size) * 0.25)",1.5:"calc(var(--tsrd-font-size) * 0.375)",2:"calc(var(--tsrd-font-size) * 0.5)",2.5:"calc(var(--tsrd-font-size) * 0.625)",3:"calc(var(--tsrd-font-size) * 0.75)",3.5:"calc(var(--tsrd-font-size) * 0.875)",4:"calc(var(--tsrd-font-size) * 1)",5:"calc(var(--tsrd-font-size) * 1.25)",8:"calc(var(--tsrd-font-size) * 2)"}},At=t=>{const{colors:e,font:i,size:r,alpha:f,border:o}=E,{fontFamily:g,lineHeight:v,size:c}=i,a=t?de.bind({target:t}):de;return{devtoolsPanelContainer:a`
      direction: ltr;
      position: fixed;
      bottom: 0;
      right: 0;
      z-index: 99999;
      width: 100%;
      max-height: 90%;
      border-top: 1px solid ${e.gray[700]};
      transform-origin: top;
    `,devtoolsPanelContainerVisibility:n=>a`
        visibility: ${n?"visible":"hidden"};
      `,devtoolsPanelContainerResizing:n=>n()?a`
          transition: none;
        `:a`
        transition: all 0.4s ease;
      `,devtoolsPanelContainerAnimation:(n,C)=>n?a`
          pointer-events: auto;
          transform: translateY(0);
        `:a`
        pointer-events: none;
        transform: translateY(${C}px);
      `,logo:a`
      cursor: pointer;
      display: flex;
      flex-direction: column;
      background-color: transparent;
      border: none;
      font-family: ${g.sans};
      gap: ${E.size[.5]};
      padding: 0px;
      &:hover {
        opacity: 0.7;
      }
      &:focus-visible {
        outline-offset: 4px;
        border-radius: ${o.radius.xs};
        outline: 2px solid ${e.blue[800]};
      }
    `,tanstackLogo:a`
      font-size: ${i.size.md};
      font-weight: ${i.weight.bold};
      line-height: ${i.lineHeight.xs};
      white-space: nowrap;
      color: ${e.gray[300]};
    `,routerLogo:a`
      font-weight: ${i.weight.semibold};
      font-size: ${i.size.xs};
      background: linear-gradient(to right, #84cc16, #10b981);
      background-clip: text;
      -webkit-background-clip: text;
      line-height: 1;
      -webkit-text-fill-color: transparent;
      white-space: nowrap;
    `,devtoolsPanel:a`
      display: flex;
      font-size: ${c.sm};
      font-family: ${g.sans};
      background-color: ${e.darkGray[700]};
      color: ${e.gray[300]};

      @media (max-width: 700px) {
        flex-direction: column;
      }
      @media (max-width: 600px) {
        font-size: ${c.xs};
      }
    `,dragHandle:a`
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 4px;
      cursor: row-resize;
      z-index: 100000;
      &:hover {
        background-color: ${e.purple[400]}${f[90]};
      }
    `,firstContainer:a`
      flex: 1 1 500px;
      min-height: 40%;
      max-height: 100%;
      overflow: auto;
      border-right: 1px solid ${e.gray[700]};
      display: flex;
      flex-direction: column;
    `,routerExplorerContainer:a`
      overflow-y: auto;
      flex: 1;
    `,routerExplorer:a`
      padding: ${E.size[2]};
    `,row:a`
      display: flex;
      align-items: center;
      padding: ${E.size[2]} ${E.size[2.5]};
      gap: ${E.size[2.5]};
      border-bottom: ${e.darkGray[500]} 1px solid;
      align-items: center;
    `,detailsHeader:a`
      font-family: ui-sans-serif, Inter, system-ui, sans-serif, sans-serif;
      position: sticky;
      top: 0;
      z-index: 2;
      background-color: ${e.darkGray[600]};
      padding: 0px ${E.size[2]};
      font-weight: ${i.weight.medium};
      font-size: ${i.size.xs};
      min-height: ${E.size[8]};
      line-height: ${i.lineHeight.xs};
      text-align: left;
      display: flex;
      align-items: center;
    `,maskedBadge:a`
      background: ${e.yellow[900]}${f[70]};
      color: ${e.yellow[300]};
      display: inline-block;
      padding: ${E.size[0]} ${E.size[2.5]};
      border-radius: ${o.radius.full};
      font-size: ${i.size.xs};
      font-weight: ${i.weight.normal};
      border: 1px solid ${e.yellow[300]};
    `,maskedLocation:a`
      color: ${e.yellow[300]};
    `,detailsContent:a`
      padding: ${E.size[1.5]} ${E.size[2]};
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: ${i.size.xs};
    `,routeMatchesToggle:a`
      display: flex;
      align-items: center;
      border: 1px solid ${e.gray[500]};
      border-radius: ${o.radius.sm};
      overflow: hidden;
    `,routeMatchesToggleBtn:(n,C)=>{const p=[a`
        appearance: none;
        border: none;
        font-size: 12px;
        padding: 4px 8px;
        background: transparent;
        cursor: pointer;
        font-family: ${g.sans};
        font-weight: ${i.weight.medium};
      `];if(n){const A=a`
          background: ${e.darkGray[400]};
          color: ${e.gray[300]};
        `;p.push(A)}else{const A=a`
          color: ${e.gray[500]};
          background: ${e.darkGray[800]}${f[20]};
        `;p.push(A)}return C&&p.push(a`
          border-right: 1px solid ${E.colors.gray[500]};
        `),p},detailsHeaderInfo:a`
      flex: 1;
      justify-content: flex-end;
      display: flex;
      align-items: center;
      font-weight: ${i.weight.normal};
      color: ${e.gray[400]};
    `,matchRow:n=>{const C=[a`
        display: flex;
        border-bottom: 1px solid ${e.darkGray[400]};
        cursor: pointer;
        align-items: center;
        padding: ${r[1]} ${r[2]};
        gap: ${r[2]};
        font-size: ${c.xs};
        color: ${e.gray[300]};
      `];if(n){const p=a`
          background: ${e.darkGray[500]};
        `;C.push(p)}return C},matchIndicator:n=>{const C=[a`
        flex: 0 0 auto;
        width: ${r[3]};
        height: ${r[3]};
        background: ${e[n][900]};
        border: 1px solid ${e[n][500]};
        border-radius: ${o.radius.full};
        transition: all 0.25s ease-out;
        box-sizing: border-box;
      `];if(n==="gray"){const p=a`
          background: ${e.gray[700]};
          border-color: ${e.gray[400]};
        `;C.push(p)}return C},matchID:a`
      flex: 1;
      line-height: ${v.xs};
    `,ageTicker:n=>{const C=[a`
        display: flex;
        gap: ${r[1]};
        font-size: ${c.xs};
        color: ${e.gray[400]};
        font-variant-numeric: tabular-nums;
        line-height: ${v.xs};
      `];if(n){const p=a`
          color: ${e.yellow[400]};
        `;C.push(p)}return C},secondContainer:a`
      flex: 1 1 500px;
      min-height: 40%;
      max-height: 100%;
      overflow: auto;
      border-right: 1px solid ${e.gray[700]};
      display: flex;
      flex-direction: column;
    `,thirdContainer:a`
      flex: 1 1 500px;
      overflow: auto;
      display: flex;
      flex-direction: column;
      height: 100%;
      border-right: 1px solid ${e.gray[700]};

      @media (max-width: 700px) {
        border-top: 2px solid ${e.gray[700]};
      }
    `,fourthContainer:a`
      flex: 1 1 500px;
      min-height: 40%;
      max-height: 100%;
      overflow: auto;
      display: flex;
      flex-direction: column;
    `,routesContainer:a`
      overflow-x: auto;
      overflow-y: visible;
    `,routesRowContainer:(n,C)=>{const p=[a`
        display: flex;
        border-bottom: 1px solid ${e.darkGray[400]};
        align-items: center;
        padding: ${r[1]} ${r[2]};
        gap: ${r[2]};
        font-size: ${c.xs};
        color: ${e.gray[300]};
        cursor: ${C?"pointer":"default"};
        line-height: ${v.xs};
      `];if(n){const A=a`
          background: ${e.darkGray[500]};
        `;p.push(A)}return p},routesRow:n=>{const C=[a`
        flex: 1 0 auto;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: ${c.xs};
        line-height: ${v.xs};
      `];if(!n){const p=a`
          color: ${e.gray[400]};
        `;C.push(p)}return C},routesRowInner:a`
      display: 'flex';
      align-items: 'center';
      flex-grow: 1;
      min-width: 0;
    `,routeParamInfo:a`
      color: ${e.gray[400]};
      font-size: ${c.xs};
      line-height: ${v.xs};
    `,nestedRouteRow:n=>a`
        margin-left: ${n?0:r[3.5]};
        border-left: ${n?"":`solid 1px ${e.gray[700]}`};
      `,code:a`
      font-size: ${c.xs};
      line-height: ${v.xs};
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    `,matchesContainer:a`
      flex: 1 1 auto;
      overflow-y: auto;
    `,cachedMatchesContainer:a`
      flex: 1 1 auto;
      overflow-y: auto;
      max-height: 50%;
    `,historyContainer:a`
      display: flex;
      flex: 1 1 auto;
      overflow-y: auto;
      max-height: 50%;
    `,historyOverflowContainer:a`
      padding: ${r[1]} ${r[2]};
      font-size: ${E.font.size.xs};
    `,maskedBadgeContainer:a`
      flex: 1;
      justify-content: flex-end;
      display: flex;
    `,matchDetails:a`
      display: flex;
      flex-direction: column;
      padding: ${E.size[2]};
      font-size: ${E.font.size.xs};
      color: ${E.colors.gray[300]};
      line-height: ${E.font.lineHeight.sm};
    `,matchStatus:(n,C)=>{const p=C&&n==="success"?C==="beforeLoad"?"purple":"blue":{pending:"yellow",success:"green",error:"red",notFound:"purple",redirected:"gray"}[n];return a`
        display: flex;
        justify-content: center;
        align-items: center;
        height: 40px;
        border-radius: ${E.border.radius.sm};
        font-weight: ${E.font.weight.normal};
        background-color: ${E.colors[p][900]}${E.alpha[90]};
        color: ${E.colors[p][300]};
        border: 1px solid ${E.colors[p][600]};
        margin-bottom: ${E.size[2]};
        transition: all 0.25s ease-out;
      `},matchDetailsInfo:a`
      display: flex;
      justify-content: flex-end;
      flex: 1;
    `,matchDetailsInfoLabel:a`
      display: flex;
    `,mainCloseBtn:a`
      background: ${e.darkGray[700]};
      padding: ${r[1]} ${r[2]} ${r[1]} ${r[1.5]};
      border-radius: ${o.radius.md};
      position: fixed;
      z-index: 99999;
      display: inline-flex;
      width: fit-content;
      cursor: pointer;
      appearance: none;
      border: 0;
      gap: 8px;
      align-items: center;
      border: 1px solid ${e.gray[500]};
      font-size: ${i.size.xs};
      cursor: pointer;
      transition: all 0.25s ease-out;

      &:hover {
        background: ${e.darkGray[500]};
      }
    `,mainCloseBtnPosition:n=>a`
        ${n==="top-left"?`top: ${r[2]}; left: ${r[2]};`:""}
        ${n==="top-right"?`top: ${r[2]}; right: ${r[2]};`:""}
        ${n==="bottom-left"?`bottom: ${r[2]}; left: ${r[2]};`:""}
        ${n==="bottom-right"?`bottom: ${r[2]}; right: ${r[2]};`:""}
      `,mainCloseBtnAnimation:n=>n?a`
        opacity: 0;
        pointer-events: none;
        visibility: hidden;
      `:a`
          opacity: 1;
          pointer-events: auto;
          visibility: visible;
        `,routerLogoCloseButton:a`
      font-weight: ${i.weight.semibold};
      font-size: ${i.size.xs};
      background: linear-gradient(to right, #98f30c, #00f4a3);
      background-clip: text;
      -webkit-background-clip: text;
      line-height: 1;
      -webkit-text-fill-color: transparent;
      white-space: nowrap;
    `,mainCloseBtnDivider:a`
      width: 1px;
      background: ${E.colors.gray[600]};
      height: 100%;
      border-radius: 999999px;
      color: transparent;
    `,mainCloseBtnIconContainer:a`
      position: relative;
      width: ${r[5]};
      height: ${r[5]};
      background: pink;
      border-radius: 999999px;
      overflow: hidden;
    `,mainCloseBtnIconOuter:a`
      width: ${r[5]};
      height: ${r[5]};
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      filter: blur(3px) saturate(1.8) contrast(2);
    `,mainCloseBtnIconInner:a`
      width: ${r[4]};
      height: ${r[4]};
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    `,panelCloseBtn:a`
      position: absolute;
      cursor: pointer;
      z-index: 100001;
      display: flex;
      align-items: center;
      justify-content: center;
      outline: none;
      background-color: ${e.darkGray[700]};
      &:hover {
        background-color: ${e.darkGray[500]};
      }

      top: 0;
      right: ${r[2]};
      transform: translate(0, -100%);
      border-right: ${e.darkGray[300]} 1px solid;
      border-left: ${e.darkGray[300]} 1px solid;
      border-top: ${e.darkGray[300]} 1px solid;
      border-bottom: none;
      border-radius: ${o.radius.sm} ${o.radius.sm} 0px 0px;
      padding: ${r[1]} ${r[1.5]} ${r[.5]} ${r[1.5]};

      &::after {
        content: ' ';
        position: absolute;
        top: 100%;
        left: -${r[2.5]};
        height: ${r[1.5]};
        width: calc(100% + ${r[5]});
      }
    `,panelCloseBtnIcon:a`
      color: ${e.gray[400]};
      width: ${r[2]};
      height: ${r[2]};
    `,navigateButton:a`
      background: none;
      border: none;
      padding: 0 0 0 4px;
      margin: 0;
      color: ${e.gray[400]};
      font-size: ${c.md};
      cursor: pointer;
      line-height: 1;
      vertical-align: middle;
      margin-right: 0.5ch;
      flex-shrink: 0;
      &:hover {
        color: ${e.blue[300]};
      }
    `}};function ye(){const[t]=Z(At(ft(gt)));return t}var Mt=t=>{try{const e=localStorage.getItem(t);return typeof e=="string"?JSON.parse(e):void 0}catch{return}};function ot(t,e){const[i,r]=Z();return be(()=>{const o=Mt(t);r(typeof o>"u"||o===null?typeof e=="function"?e():e:o)}),[i,o=>{r(g=>{let v=o;typeof o=="function"&&(v=o(g));try{localStorage.setItem(t,JSON.stringify(v))}catch{}return v})}]}var Rt=typeof window>"u";function Ne(t){return t.isFetching&&t.status==="success"?t.isFetching==="beforeLoad"?"purple":"blue":{pending:"yellow",success:"green",error:"red",notFound:"purple",redirected:"gray"}[t.status]}function Pt(t,e){const i=t.find(r=>r.routeId===e.id);return i?Ne(i):"gray"}function yr(){const[t,e]=Z(!1);return(Rt?be:b)(()=>{e(!0)}),t}var Lt=Symbol.for("tanstack.rsc.stream"),at=Symbol.for("tanstack.rsc.renderable"),De=Symbol.for("tanstack.rsc.slotUsages");function Ot(t){let e=t.length;for(;e>0&&t[e-1]===void 0;)e--;return e===0||e===t.length?t:t.slice(0,e)}var Je=t=>(typeof t=="object"||typeof t=="function")&&t!==null&&Lt in t,ht=t=>{if(!Je(t))return null;const e=t;return at in e&&e[at]===!0?"renderableValue":"compositeSource"},pt=t=>{if(!Je(t))return[];const e=t,i=[];if(De in e){const r=e[De];if(Array.isArray(r))for(const f of r){const o=f?.slot;typeof o=="string"&&!i.includes(o)&&i.push(o)}}return i},jt=t=>{if(!Je(t))return[];const e=t;if(!(De in e))return[];const i=e[De];return Array.isArray(i)?i.filter(r=>r&&typeof r=="object"&&typeof r.slot=="string"&&(r.args===void 0||Array.isArray(r.args))):[]},Ht=t=>{const e=jt(t),i={};for(const r of e){const f=Ot(r.args??[]),o=i[r.slot]??(i[r.slot]={count:0,invocations:[]});o.count++,o.invocations.push(f)}return i},Oe=t=>{if(t==="React element")return"React element";const e=ht(t);if(e==="compositeSource"){const f=pt(t);return f.length>0?`RSC composite source (${f.length} ${f.length===1?"slot":"slots"})`:"RSC composite source"}if(e==="renderableValue")return"RSC renderable value";const i=Object.getOwnPropertyNames(Object(t)),r=typeof t=="bigint"?`${t.toString()}n`:t;try{return JSON.stringify(r,i)}catch{return"unable to stringify"}};function Gt(t,e=[i=>i]){return t.map((i,r)=>[i,r]).sort(([i,r],[f,o])=>{for(const g of e){const v=g(i),c=g(f);if(typeof v>"u"){if(typeof c>"u")continue;return 1}if(v!==c)return v>c?1:-1}return r-o}).map(([i])=>i)}var Nt=_('<span><svg xmlns=http://www.w3.org/2000/svg width=12 height=12 fill=none viewBox="0 0 24 24"><path stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 18l6-6-6-6">'),_e=_("<div>"),Vt=_("<button><span>:</span><span>"),Ut=_("<div><span>slots</span><div>"),st=_("<span>:"),lt=_("<span>"),Jt=_("<button><span> "),Yt=_("<div><div><button> [<!> ... <!>]"),qt=_("<button><span></span> 🔄 "),je=({expanded:t,style:e={}})=>{const i=mt();return(()=>{var r=Nt(),f=r.firstChild;return b(o=>{var g=i().expander,v=U(i().expanderIcon(t));return g!==o.e&&l(r,o.e=g),v!==o.t&&se(f,"class",o.t=v),o},{e:void 0,t:void 0}),r})()};function Kt(t,e){if(e<1)return[];let i=0;const r=[];for(;i<t.length;)r.push(t.slice(i,i+e)),i=i+e;return r}function Wt(t){return Symbol.iterator in t}function Zt(t){if(!t||typeof t!="object")return!1;const e=Object.getPrototypeOf(t);return e===Object.prototype||e===null}function ae({value:t,defaultExpanded:e,pageSize:i=100,filterSubEntries:r,...f}){const[o,g]=Z(!!e),v=()=>g(T=>!T),c=J(()=>typeof t()),a=J(()=>{let T=[];const W=s=>{const y=e===!0?{[s.label]:!0}:e?.[s.label];return{...s,value:()=>s.value,defaultExpanded:y}};if(Array.isArray(t())&&t().length===2&&t()[0]==="React element"&&Zt(t()[1])){const s=t();T=[W({label:"0",value:s[0]}),...Object.entries(s[1]).map(([y,M])=>W({label:y,value:M}))]}else Array.isArray(t())?T=t().map((s,y)=>W({label:y.toString(),value:s})):t()!==null&&typeof t()=="object"&&Wt(t())&&typeof t()[Symbol.iterator]=="function"?T=Array.from(t(),(s,y)=>W({label:y.toString(),value:s})):typeof t()=="object"&&t()!==null&&(T=Object.entries(t()).map(([s,y])=>W({label:s,value:y})));return r?r(T):T}),n=J(()=>Kt(a(),i)),[C,p]=Z([]),[A,H]=Z(void 0),m=mt(),Y=()=>{H(t()())},K=T=>w(ae,Ve({value:t,filterSubEntries:r},f,T)),Q=J(()=>ht(t())),xe=J(()=>pt(t())),Ie=J(()=>Ht(t())),Te=J(()=>Q()==="compositeSource"&&xe().length>0);return(()=>{var T=_e();return u(T,(()=>{var W=L(()=>Q()!==null);return()=>W()?L(()=>!!Te())()?[(()=>{var s=Vt(),y=s.firstChild,M=y.firstChild,I=y.nextSibling;return s.$$click=()=>v(),u(s,w(je,{get expanded(){return o()??!1}}),y),u(y,()=>f.label,M),u(I,()=>Oe(t())),b(R=>{var P=m().expandButton,X=m().compositeComponent;return P!==R.e&&l(s,R.e=P),X!==R.t&&l(I,R.t=X),R},{e:void 0,t:void 0}),s})(),L(()=>L(()=>!!(o()??!1))()?(()=>{var s=Ut(),y=s.firstChild,M=y.nextSibling;return u(M,()=>xe().map(I=>{const R=Ie()[I];return R?w(ae,{label:`${I}:`,value:()=>R.invocations.map(P=>P.length===1?P[0]:P)}):null})),b(I=>{var R=m().rscMetaRow,P=m().rscMetaLabel,X=m().subEntries;return R!==I.e&&l(s,I.e=R),P!==I.t&&l(y,I.t=P),X!==I.a&&l(M,I.a=X),I},{e:void 0,t:void 0,a:void 0}),s})():null)]:[(()=>{var s=st(),y=s.firstChild;return u(s,()=>f.label,y),s})()," ",(()=>{var s=lt();return u(s,()=>Oe(t())),b(()=>l(s,Q()==="compositeSource"?m().compositeComponent:m().renderableComponent)),s})()]:L(()=>!!n().length)()?[(()=>{var s=Jt(),y=s.firstChild,M=y.firstChild;return s.$$click=()=>v(),u(s,w(je,{get expanded(){return o()??!1}}),y),u(s,()=>f.label,y),u(y,()=>String(c).toLowerCase()==="iterable"?"(Iterable) ":"",M),u(y,()=>a().length,M),u(y,()=>a().length>1?"items":"item",null),b(I=>{var R=m().expandButton,P=m().info;return R!==I.e&&l(s,I.e=R),P!==I.t&&l(y,I.t=P),I},{e:void 0,t:void 0}),s})(),L(()=>L(()=>!!(o()??!1))()?L(()=>n().length===1)()?(()=>{var s=_e();return u(s,()=>a().map((y,M)=>K(y))),b(()=>l(s,m().subEntries)),s})():(()=>{var s=_e();return u(s,()=>n().map((y,M)=>(()=>{var I=Yt(),R=I.firstChild,P=R.firstChild,X=P.firstChild,D=X.nextSibling,G=D.nextSibling.nextSibling;return G.nextSibling,P.$$click=()=>p(N=>N.includes(M)?N.filter(O=>O!==M):[...N,M]),u(P,w(je,{get expanded(){return C().includes(M)}}),X),u(P,M*i,D),u(P,M*i+i-1,G),u(R,(()=>{var N=L(()=>!!C().includes(M));return()=>N()?(()=>{var O=_e();return u(O,()=>y.map(V=>K(V))),b(()=>l(O,m().subEntries)),O})():null})(),null),b(N=>{var O=m().entry,V=U(m().labelButton,"labelButton");return O!==N.e&&l(R,N.e=O),V!==N.t&&l(P,N.t=V),N},{e:void 0,t:void 0}),I})())),b(()=>l(s,m().subEntries)),s})():null)]:L(()=>c()==="function")()?w(ae,{get label(){return(()=>{var s=qt(),y=s.firstChild;return s.$$click=Y,u(y,()=>f.label),b(()=>l(s,m().refreshValueBtn)),s})()},value:A,defaultExpanded:{}}):[(()=>{var s=st(),y=s.firstChild;return u(s,()=>f.label,y),s})()," ",(()=>{var s=lt();return u(s,()=>Oe(t())),b(()=>l(s,m().value)),s})()]})()),b(()=>l(T,m().entry)),T})()}var Qt=t=>{const{colors:e,font:i,size:r,border:f}=E,{fontFamily:o,lineHeight:g,size:v}=i,c=t?de.bind({target:t}):de;return{entry:c`
      font-family: ${o.mono};
      font-size: ${v.xs};
      line-height: ${g.sm};
      outline: none;
      word-break: break-word;
    `,labelButton:c`
      cursor: pointer;
      color: inherit;
      font: inherit;
      outline: inherit;
      background: transparent;
      border: none;
      padding: 0;
    `,expander:c`
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: ${r[3]};
      height: ${r[3]};
      padding-left: 3px;
      box-sizing: content-box;
    `,expanderIcon:a=>a?c`
          transform: rotate(90deg);
          transition: transform 0.1s ease;
        `:c`
        transform: rotate(0deg);
        transition: transform 0.1s ease;
      `,expandButton:c`
      display: flex;
      gap: ${r[1]};
      align-items: center;
      cursor: pointer;
      color: inherit;
      font: inherit;
      outline: inherit;
      background: transparent;
      border: none;
      padding: 0;
    `,value:c`
      color: ${e.purple[400]};
    `,compositeComponent:c`
      display: inline-flex;
      align-items: center;
      padding: 1px ${r[1]};
      border-radius: ${f.radius.full};
      border: 1px solid ${e.darkGray[500]};
      background: ${e.darkGray[700]};
      color: ${e.cyan[300]};
      font-style: normal;
      font-weight: ${i.weight.medium};
    `,renderableComponent:c`
      display: inline-flex;
      align-items: center;
      padding: 1px ${r[1]};
      border-radius: ${f.radius.full};
      border: 1px solid ${e.darkGray[500]};
      background: ${e.darkGray[700]};
      color: ${e.teal[300]};
      font-style: normal;
      font-weight: ${i.weight.medium};
    `,rscMetaRow:c`
      display: flex;
      gap: ${r[1]};
      align-items: flex-start;
      margin-left: calc(${r[3]} + ${r[1]});
      margin-top: ${r[.5]};
      flex-wrap: wrap;
    `,rscMetaLabel:c`
      color: ${e.gray[500]};
      font-size: ${v["2xs"]};
      text-transform: uppercase;
      letter-spacing: 0.06em;
      padding-top: 2px;
    `,rscChipRow:c`
      display: flex;
      gap: ${r[1]};
      flex-wrap: wrap;
    `,rscChip:c`
      display: inline-flex;
      align-items: center;
      gap: ${r[.5]};
      padding: 1px ${r[1]};
      border-radius: ${f.radius.full};
      border: 1px solid ${e.darkGray[500]};
      background: ${e.darkGray[800]};
      color: ${e.gray[200]};
      font-size: ${v["2xs"]};
      line-height: ${g.xs};
    `,rscChipName:c`
      color: ${e.gray[100]};
    `,rscChipMeta:c`
      color: ${e.gray[400]};
      font-size: ${v["2xs"]};
    `,subEntries:c`
      margin-left: ${r[2]};
      padding-left: ${r[2]};
      border-left: 2px solid ${e.darkGray[400]};
    `,info:c`
      color: ${e.gray[500]};
      font-size: ${v["2xs"]};
      padding-left: ${r[1]};
    `,refreshValueBtn:c`
      appearance: none;
      border: 0;
      cursor: pointer;
      background: transparent;
      color: inherit;
      padding: 0;
      font-family: ${o.mono};
      font-size: ${v.xs};
    `}};function mt(){const[t]=Z(Qt(ft(gt)));return t}Ue(["click"]);var Xt=_("<div><div></div><div>/</div><div></div><div>/</div><div>");function He(t){const e=["s","min","h","d"],i=[t/1e3,t/6e4,t/36e5,t/864e5];let r=0;for(let f=1;f<i.length&&!(i[f]<1);f++)r=f;return new Intl.NumberFormat(navigator.language,{compactDisplay:"short",notation:"compact",maximumFractionDigits:0}).format(i[r])+e[r]}function Fe({match:t,router:e}){const i=ye();if(!t)return null;const r=e().looseRoutesById[t.routeId];if(!r.options.loader)return null;const f=Date.now()-t.updatedAt,o=r.options.staleTime??e().options.defaultStaleTime??0,g=r.options.gcTime??e().options.defaultGcTime??1800*1e3;return(()=>{var v=Xt(),c=v.firstChild,a=c.nextSibling.nextSibling,n=a.nextSibling.nextSibling;return u(c,()=>He(f)),u(a,()=>He(o)),u(n,()=>He(g)),b(()=>l(v,U(i().ageTicker(f>o)))),v})()}var er=_("<button type=button>➔");function ze({to:t,params:e,search:i,router:r}){const f=ye();return(()=>{var o=er();return o.$$click=g=>{g.stopPropagation(),r().navigate({to:t,params:e,search:i})},se(o,"title",`Navigate to ${t}`),b(()=>l(o,f().navigateButton)),o})()}Ue(["click"]);var tr=_("<button><div>TANSTACK</div><div>TanStack Router v1"),rr=_("<div style=display:flex;align-items:center;width:100%><div style=flex-grow:1;min-width:0>"),nr=_("<code> "),$e=_("<code>"),ir=_("<div><div role=button><div>"),Ee=_("<div>"),or=_("<div><ul>"),ar=_('<div><button><svg xmlns=http://www.w3.org/2000/svg width=10 height=6 fill=none viewBox="0 0 10 6"><path stroke=currentColor stroke-linecap=round stroke-linejoin=round stroke-width=1.667 d="M1 1l4 4 4-4"></path></svg></button><div><div></div><div><div></div></div></div><div><div><div><span>Pathname</span></div><div><code></code></div><div><div><button type=button>Routes</button><button type=button>Matches</button><button type=button>History</button></div><div><div>age / staleTime / gcTime</div></div></div><div>'),sr=_("<div><span>masked"),dt=_("<div role=button><div>"),lr=_("<li><div>"),dr=_("<li>This panel displays the most recent 15 navigations."),cr=_("<div><div><div>Cached Matches</div><div>age / staleTime / gcTime</div></div><div>"),ur=_("<div><div>Match Details</div><div><div><div><div></div></div><div><div>ID:</div><div><code></code></div></div><div><div>State:</div><div></div></div><div><div>Last Updated:</div><div></div></div></div></div><div>Explorer</div><div>"),fr=_("<div>Loader Data"),gr=_("<div><div><span>Search Params</span></div><div>"),vr=_("<span style=margin-left:0.5rem>"),hr=_('<button type=button aria-label="Copy value to clipboard"style=cursor:pointer>'),ct=15;function pr(t){const{className:e,...i}=t,r=ye();return(()=>{var f=tr(),o=f.firstChild,g=o.nextSibling;return ut(f,Ve(i,{get class(){return U(r().logo,e?e():"")}}),!1,!0),b(v=>{var c=r().tanstackLogo,a=r().routerLogo;return c!==v.e&&l(o,v.e=c),a!==v.t&&l(g,v.t=a),v},{e:void 0,t:void 0}),f})()}function Be(t){return(()=>{var e=rr(),i=e.firstChild;return u(e,()=>t.left,i),u(i,()=>t.children),u(e,()=>t.right,null),b(()=>l(e,t.class)),e})()}function $t({routerState:t,pendingMatches:e,router:i,route:r,isRoot:f,activeId:o,setActiveId:g}){const v=ye(),c=J(()=>e().length?e():t().matches),a=J(()=>t().matches.find(p=>p.routeId===r.id)),n=J(()=>{try{if(a()?.params){const p=a()?.params,A=r.path||nt(r.id);if(A.startsWith("$")){const H=A.slice(1);if(p[H])return`(${p[H]})`}}return""}catch{return""}}),C=J(()=>{if(f||!r.path)return;const p=Object.assign({},...c().map(H=>H.params)),A=Ft({path:r.fullPath,params:p,decoder:i().pathParamsDecoder});return A.isMissingParams?void 0:A.interpolatedPath});return(()=>{var p=ir(),A=p.firstChild,H=A.firstChild;return A.$$click=()=>{a()&&g(o()===r.id?"":r.id)},u(A,w(Be,{get class(){return U(v().routesRow(!!a()))},get left(){return w(St,{get when(){return C()},children:m=>w(ze,{get to(){return m()},router:i})})},get right(){return w(Fe,{get match(){return a()},router:i})},get children(){return[(()=>{var m=nr(),Y=m.firstChild;return u(m,()=>f?me:r.path||nt(r.id),Y),b(()=>l(m,v().code)),m})(),(()=>{var m=$e();return u(m,n),b(()=>l(m,v().routeParamInfo)),m})()]}}),null),u(p,(()=>{var m=L(()=>!!r.children?.length);return()=>m()?(()=>{var Y=Ee();return u(Y,()=>[...r.children].sort((K,Q)=>K.rank-Q.rank).map(K=>w($t,{routerState:t,pendingMatches:e,router:i,route:K,activeId:o,setActiveId:g}))),b(()=>l(Y,v().nestedRouteRow(!!f))),Y})():null})(),null),b(m=>{var Y=`Open match details for ${r.id}`,K=U(v().routesRowContainer(r.id===o(),!!a())),Q=U(v().matchIndicator(Pt(c(),r)));return Y!==m.e&&se(A,"aria-label",m.e=Y),K!==m.t&&l(A,m.t=K),Q!==m.a&&l(H,m.a=Q),m},{e:void 0,t:void 0,a:void 0}),p})()}var xr=function({...e}){const{isOpen:i=!0,setIsOpen:r,handleDragStart:f,router:o,routerState:g,shadowDOMTarget:v,...c}=e,{onCloseClick:a}=xt(),n=ye(),{className:C,style:p,...A}=c,[H,m]=ot("tanstackRouterDevtoolsActiveTab","routes"),[Y,K]=ot("tanstackRouterDevtoolsActiveRouteId",""),[Q,xe]=Z([]),[Ie,Te]=Z(!1);let T,W;if("subscribe"in o().stores.pendingMatches){const[D,G]=Z([]);T=D;const[N,O]=Z([]);W=N,be(()=>{const V=o().stores.pendingMatches;G(V.get());const te=V.subscribe(()=>{G(V.get())});Ge(()=>te.unsubscribe())}),be(()=>{const V=o().stores.cachedMatches;O(V.get());const te=V.subscribe(()=>{O(V.get())});Ge(()=>te.unsubscribe())})}else T=()=>o().stores.pendingMatches.get(),W=()=>o().stores.cachedMatches.get();be(()=>{const D=g().matches,G=D[D.length-1];if(!G)return;const N=_t(()=>Q()),O=N[0],V=O&&O.pathname===G.pathname&&JSON.stringify(O.search??{})===JSON.stringify(G.search??{});(!O||!V)&&(N.length>=ct&&Te(!0),xe(te=>{const ce=[G,...te];return ce.splice(ct),ce}))});const s=J(()=>[...T(),...g().matches,...W()].find(D=>D.routeId===Y()||D.id===Y())),y=J(()=>Object.keys(g().location.search).length),M=J(()=>({...o(),state:g()})),I=J(()=>Object.fromEntries(Gt(Object.keys(M()),["state","routesById","routesByPath","options","manifest"].map(D=>G=>G!==D)).map(D=>[D,M()[D]]).filter(D=>typeof D[1]!="function"&&!["stores","basepath","injectedHtml","subscribers","latestLoadPromise","navigateTimeout","resetNextScroll","tempLocationKey","latestLocation","routeTree","history"].includes(D[0])))),R=J(()=>s()?.loaderData),P=J(()=>s()),X=J(()=>g().location.search);return(()=>{var D=ar(),G=D.firstChild,N=G.firstChild,O=G.nextSibling,V=O.firstChild,te=V.nextSibling,ce=te.firstChild,Ae=O.nextSibling,Ye=Ae.firstChild,Ce=Ye.firstChild;Ce.firstChild;var we=Ce.nextSibling,bt=we.firstChild,Me=we.nextSibling,Re=Me.firstChild,ke=Re.firstChild,Se=ke.nextSibling,Pe=Se.nextSibling,yt=Re.nextSibling,qe=Me.nextSibling;return ut(D,Ve({get class(){return U(n().devtoolsPanel,"TanStackRouterDevtoolsPanel",C?C():"")},get style(){return p?p():""}},A),!1,!0),u(D,f?(()=>{var d=Ee();return Ct(d,"mousedown",f,!0),b(()=>l(d,n().dragHandle)),d})():null,G),G.$$click=d=>{r&&r(!1),a(d)},u(V,w(pr,{"aria-hidden":!0,onClick:d=>{r&&r(!1),a(d)}})),u(ce,w(ae,{label:"Router",value:I,defaultExpanded:{state:{},context:{},options:{}},filterSubEntries:d=>d.filter($=>typeof $.value()!="function")})),u(Ce,(()=>{var d=L(()=>!!g().location.maskedLocation);return()=>d()?(()=>{var $=sr(),z=$.firstChild;return b(F=>{var k=n().maskedBadgeContainer,h=n().maskedBadge;return k!==F.e&&l($,F.e=k),h!==F.t&&l(z,F.t=h),F},{e:void 0,t:void 0}),$})():null})(),null),u(bt,()=>g().location.pathname),u(we,(()=>{var d=L(()=>!!g().location.maskedLocation);return()=>d()?(()=>{var $=$e();return u($,()=>g().location.maskedLocation?.pathname),b(()=>l($,n().maskedLocation)),$})():null})(),null),ke.$$click=()=>{m("routes")},Se.$$click=()=>{m("matches")},Pe.$$click=()=>{m("history")},u(qe,w(kt,{get children(){return[w(Le,{get when(){return H()==="routes"},get children(){return w($t,{routerState:g,pendingMatches:T,router:o,get route(){return o().routeTree},isRoot:!0,activeId:Y,setActiveId:K})}}),w(Le,{get when(){return H()==="matches"},get children(){var d=Ee();return u(d,()=>(T().length?T():g().matches).map(($,z)=>(()=>{var F=dt(),k=F.firstChild;return F.$$click=()=>K(Y()===$.id?"":$.id),u(F,w(Be,{get left(){return w(ze,{get to(){return $.pathname},get params(){return $.params},get search(){return $.search},router:o})},get right(){return w(Fe,{match:$,router:o})},get children(){var h=$e();return u(h,()=>`${$.routeId===me?me:$.pathname}`),b(()=>l(h,n().matchID)),h}}),null),b(h=>{var S=`Open match details for ${$.id}`,j=U(n().matchRow($===s())),B=U(n().matchIndicator(Ne($)));return S!==h.e&&se(F,"aria-label",h.e=S),j!==h.t&&l(F,h.t=j),B!==h.a&&l(k,h.a=B),h},{e:void 0,t:void 0,a:void 0}),F})())),d}}),w(Le,{get when(){return H()==="history"},get children(){var d=or(),$=d.firstChild;return u($,w(wt,{get each(){return Q()},children:(z,F)=>(()=>{var k=lr(),h=k.firstChild;return u(k,w(Be,{get left(){return w(ze,{get to(){return z.pathname},get params(){return z.params},get search(){return z.search},router:o})},get right(){return w(Fe,{match:z,router:o})},get children(){var S=$e();return u(S,()=>`${z.routeId===me?me:z.pathname}`),b(()=>l(S,n().matchID)),S}}),null),b(S=>{var j=U(n().matchRow(z===s())),B=U(n().matchIndicator(F()===0?"green":"gray"));return j!==S.e&&l(k,S.e=j),B!==S.t&&l(h,S.t=B),S},{e:void 0,t:void 0}),k})()}),null),u($,(()=>{var z=L(()=>!!Ie());return()=>z()?(()=>{var F=dr();return b(()=>l(F,n().historyOverflowContainer)),F})():null})(),null),d}})]}})),u(Ae,(()=>{var d=L(()=>!!W().length);return()=>d()?(()=>{var $=cr(),z=$.firstChild,F=z.firstChild.nextSibling,k=z.nextSibling;return u(k,()=>W().map(h=>(()=>{var S=dt(),j=S.firstChild;return S.$$click=()=>K(Y()===h.id?"":h.id),u(S,w(Be,{get left(){return w(ze,{get to(){return h.pathname},get params(){return h.params},get search(){return h.search},router:o})},get right(){return w(Fe,{match:h,router:o})},get children(){var B=$e();return u(B,()=>`${h.id}`),b(()=>l(B,n().matchID)),B}}),null),b(B=>{var ie=`Open match details for ${h.id}`,ee=U(n().matchRow(h===s())),re=U(n().matchIndicator(Ne(h)));return ie!==B.e&&se(S,"aria-label",B.e=ie),ee!==B.t&&l(S,B.t=ee),re!==B.a&&l(j,B.a=re),B},{e:void 0,t:void 0,a:void 0}),S})())),b(h=>{var S=n().cachedMatchesContainer,j=n().detailsHeader,B=n().detailsHeaderInfo;return S!==h.e&&l($,h.e=S),j!==h.t&&l(z,h.t=j),B!==h.a&&l(F,h.a=B),h},{e:void 0,t:void 0,a:void 0}),$})():null})(),null),u(D,(()=>{var d=L(()=>!!(s()&&s()?.status));return()=>d()?(()=>{var $=ur(),z=$.firstChild,F=z.nextSibling,k=F.firstChild,h=k.firstChild,S=h.firstChild,j=h.nextSibling,B=j.firstChild.nextSibling,ie=B.firstChild,ee=j.nextSibling,re=ee.firstChild.nextSibling,ue=ee.nextSibling,fe=ue.firstChild.nextSibling,le=F.nextSibling,ge=le.nextSibling;return u(S,(()=>{var x=L(()=>!!(s()?.status==="success"&&s()?.isFetching));return()=>x()?"fetching":s()?.status})()),u(ie,()=>s()?.id),u(re,(()=>{var x=L(()=>!!T().find(q=>q.id===s()?.id));return()=>x()?"Pending":g().matches.find(q=>q.id===s()?.id)?"Active":"Cached"})()),u(fe,(()=>{var x=L(()=>!!s()?.updatedAt);return()=>x()?new Date(s()?.updatedAt).toLocaleTimeString():"N/A"})()),u($,(()=>{var x=L(()=>!!R());return()=>x()?[(()=>{var q=fr();return b(()=>l(q,n().detailsHeader)),q})(),(()=>{var q=Ee();return u(q,w(ae,{label:"loaderData",value:R,defaultExpanded:{}})),b(()=>l(q,n().detailsContent)),q})()]:null})(),le),u(ge,w(ae,{label:"Match",value:P,defaultExpanded:{}})),b(x=>{var q=n().thirdContainer,ve=n().detailsHeader,he=n().matchDetails,pe=n().matchStatus(s()?.status,s()?.isFetching),Ke=n().matchDetailsInfoLabel,We=n().matchDetailsInfo,Ze=n().matchDetailsInfoLabel,Qe=n().matchDetailsInfo,Xe=n().matchDetailsInfoLabel,et=n().matchDetailsInfo,tt=n().detailsHeader,rt=n().detailsContent;return q!==x.e&&l($,x.e=q),ve!==x.t&&l(z,x.t=ve),he!==x.a&&l(k,x.a=he),pe!==x.o&&l(h,x.o=pe),Ke!==x.i&&l(j,x.i=Ke),We!==x.n&&l(B,x.n=We),Ze!==x.s&&l(ee,x.s=Ze),Qe!==x.h&&l(re,x.h=Qe),Xe!==x.r&&l(ue,x.r=Xe),et!==x.d&&l(fe,x.d=et),tt!==x.l&&l(le,x.l=tt),rt!==x.u&&l(ge,x.u=rt),x},{e:void 0,t:void 0,a:void 0,o:void 0,i:void 0,n:void 0,s:void 0,h:void 0,r:void 0,d:void 0,l:void 0,u:void 0}),$})():null})(),null),u(D,(()=>{var d=L(()=>!!y());return()=>d()?(()=>{var $=gr(),z=$.firstChild;z.firstChild;var F=z.nextSibling;return u(z,typeof navigator<"u"?(()=>{var k=vr();return u(k,w(mr,{getValue:()=>{const h=g().location.search;return JSON.stringify(h)}})),k})():null,null),u(F,w(ae,{value:X,get defaultExpanded(){return Object.keys(g().location.search).reduce((k,h)=>(k[h]={},k),{})}})),b(k=>{var h=n().fourthContainer,S=n().detailsHeader,j=n().detailsContent;return h!==k.e&&l($,k.e=h),S!==k.t&&l(z,k.t=S),j!==k.a&&l(F,k.a=j),k},{e:void 0,t:void 0,a:void 0}),$})():null})(),null),b(d=>{var $=n().panelCloseBtn,z=n().panelCloseBtnIcon,F=n().firstContainer,k=n().row,h=n().routerExplorerContainer,S=n().routerExplorer,j=n().secondContainer,B=n().matchesContainer,ie=n().detailsHeader,ee=n().detailsContent,re=n().detailsHeader,ue=n().routeMatchesToggle,fe=H()==="routes",le=U(n().routeMatchesToggleBtn(H()==="routes",!0)),ge=H()==="matches",x=U(n().routeMatchesToggleBtn(H()==="matches",!0)),q=H()==="history",ve=U(n().routeMatchesToggleBtn(H()==="history",!1)),he=n().detailsHeaderInfo,pe=U(n().routesContainer);return $!==d.e&&l(G,d.e=$),z!==d.t&&se(N,"class",d.t=z),F!==d.a&&l(O,d.a=F),k!==d.o&&l(V,d.o=k),h!==d.i&&l(te,d.i=h),S!==d.n&&l(ce,d.n=S),j!==d.s&&l(Ae,d.s=j),B!==d.h&&l(Ye,d.h=B),ie!==d.r&&l(Ce,d.r=ie),ee!==d.d&&l(we,d.d=ee),re!==d.l&&l(Me,d.l=re),ue!==d.u&&l(Re,d.u=ue),fe!==d.c&&(ke.disabled=d.c=fe),le!==d.w&&l(ke,d.w=le),ge!==d.m&&(Se.disabled=d.m=ge),x!==d.f&&l(Se,d.f=x),q!==d.y&&(Pe.disabled=d.y=q),ve!==d.g&&l(Pe,d.g=ve),he!==d.p&&l(yt,d.p=he),pe!==d.b&&l(qe,d.b=pe),d},{e:void 0,t:void 0,a:void 0,o:void 0,i:void 0,n:void 0,s:void 0,h:void 0,r:void 0,d:void 0,l:void 0,u:void 0,c:void 0,w:void 0,m:void 0,f:void 0,y:void 0,g:void 0,p:void 0,b:void 0}),D})()};function mr({getValue:t}){const[e,i]=Z(!1);let r=null;const f=async()=>{if(typeof navigator>"u"||!navigator.clipboard?.writeText){console.warn("TanStack Router Devtools: Clipboard API unavailable");return}try{const o=t();await navigator.clipboard.writeText(o),i(!0),r&&clearTimeout(r),r=setTimeout(()=>i(!1),2500)}catch(o){console.error("TanStack Router Devtools: Failed to copy",o)}};return Ge(()=>{r&&clearTimeout(r)}),(()=>{var o=hr();return o.$$click=f,u(o,()=>e()?"✅":"📋"),b(()=>se(o,"title",e()?"Copied!":"Copy")),o})()}Ue(["click","mousedown"]);export{xr as BaseTanStackRouterDevtoolsPanel,xr as default,ot as n,ye as r,yr as t};
